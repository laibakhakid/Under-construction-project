<?php
/**
 * UCMM Customization Options Handler
 * 
 * This file handles the display of Under Construction, Maintenance Mode 
 * with various customization options like YouTube background video, 
 * social media links, and other settings.
 *
 * @since 1.0.0
 */

// Retrieve plugin settings
$ucmm_wpbrigade_array = (array) get_option('ucmm_wpbrigade_customization');

/**
 * Fetch a value from the customization array.
 *
 * @param string $ucmm_key
 * @param array $ucmm_wpbrigade_array
 * @return mixed
 */
function ucmm_wpbrigade_option_key($ucmm_key, $ucmm_wpbrigade_array) {
    return isset($ucmm_wpbrigade_array[$ucmm_key]) ? $ucmm_wpbrigade_array[$ucmm_key] : '';
}

/**
 * Fetch a default value if the key is not present in the array.
 *
 * @param string $ucmm_key
 * @param array $ucmm_wpbrigade_array
 * @param mixed $default
 * @return mixed
 */
function ucmm_wpbrigade_default_option_key($ucmm_key, $ucmm_wpbrigade_array, $default = true) {
    return array_key_exists($ucmm_key, $ucmm_wpbrigade_array) ? $ucmm_wpbrigade_array[$ucmm_key] : $default;
}

// Retrieve various options from the customization array
$ucmm_bg                = ucmm_wpbrigade_option_key('setting_background', $ucmm_wpbrigade_array);
$ucmm_logo              = ucmm_wpbrigade_option_key('ucmm_logo', $ucmm_wpbrigade_array);
$ucmm_header            = ucmm_wpbrigade_option_key('header_text', $ucmm_wpbrigade_array);
$ucmm_footer            = ucmm_wpbrigade_option_key('footer_text', $ucmm_wpbrigade_array);
$ucmm_logo_width        = ucmm_wpbrigade_option_key('ucmm_logo_width', $ucmm_wpbrigade_array);
$ucmm_logo_height       = ucmm_wpbrigade_option_key('ucmm_logo_height', $ucmm_wpbrigade_array);
$ucmm_seo_title         = ucmm_wpbrigade_option_key('ucmm_seo_title', $ucmm_wpbrigade_array);
$ucmm_seo_description   = ucmm_wpbrigade_option_key('ucmm_seo_description', $ucmm_wpbrigade_array);
$ucmm_seo_url           = ucmm_wpbrigade_option_key('ucmm_seo_url', $ucmm_wpbrigade_array);
$ucmm_seo_sitename      = ucmm_wpbrigade_option_key('ucmm_seo_sitename', $ucmm_wpbrigade_array);
$ucmm_seo_admin         = ucmm_wpbrigade_option_key('ucmm_seo_admin', $ucmm_wpbrigade_array);
$ucmm_seo_keywords      = ucmm_wpbrigade_option_key('ucmm_seo_keywords', $ucmm_wpbrigade_array);
$ucmm_custom_css        = ucmm_wpbrigade_option_key('ucmm_custom_css', $ucmm_wpbrigade_array);
$ucmm_ga_tracking_code  = ucmm_wpbrigade_option_key('ucmm_ga_tracking_code', $ucmm_wpbrigade_array);
$ucmm_footer_love       = ucmm_wpbrigade_default_option_key('ucmm_display_footer_text', $ucmm_wpbrigade_array);
$ucmm_schedule_end_time = ucmm_wpbrigade_option_key('ucmm_schedule_end', $ucmm_wpbrigade_array);
$ucmm_show_end_time     = ucmm_wpbrigade_option_key('ucmm_schedule_show_end_time', $ucmm_wpbrigade_array);
$ucmm_time_text_color   = ucmm_wpbrigade_option_key('ucmm_schedule_text_color', $ucmm_wpbrigade_array);
$ucmm_header_text_color = ucmm_wpbrigade_option_key('ucmm_header_text_color', $ucmm_wpbrigade_array);
$ucmm_footer_text_color = ucmm_wpbrigade_option_key('ucmm_footer_text_color', $ucmm_wpbrigade_array);
$ucmm_love_position     = ucmm_wpbrigade_option_key('ucmm_display_footer_text_position', $ucmm_wpbrigade_array);
$ucmm_love_text_color   = ucmm_wpbrigade_option_key('ucmm_love_text_color', $ucmm_wpbrigade_array);
$ucmm_mobile_bg_image   = ucmm_wpbrigade_option_key('ucmm_mobile_bg_image', $ucmm_wpbrigade_array);
$ucmm_youtube_bg_video  = ucmm_wpbrigade_option_key('ucmm_youtube_bg_video', $ucmm_wpbrigade_array);
$ucmm_enable_login      = ucmm_wpbrigade_default_option_key('ucmm_enable_frontend_login', $ucmm_wpbrigade_array, false);
$ucmm_login_bg_color    = ucmm_wpbrigade_option_key('ucmm_login_bg_color', $ucmm_wpbrigade_array);
$ucmm_login_text_color  = ucmm_wpbrigade_option_key('ucmm_login_text_color', $ucmm_wpbrigade_array);

// Social media network settings
$social_network = array('ucmm_facebook', 'ucmm_twitter', 'ucmm_linkedin', 'ucmm_youtube', 'ucmm_instagram', 'ucmm_pinterest', 'ucmm_codepen');
$social_links = array();
foreach ($social_network as $key => $value) {
    $ucmm_social_links[$value] = ucmm_wpbrigade_option_key($value, $ucmm_wpbrigade_array);
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="title" content="<?php echo esc_attr($ucmm_seo_title); ?>" />
    <meta name="description" content="<?php echo esc_attr($ucmm_seo_description); ?>" />
    <meta name="url" content="<?php echo esc_url($ucmm_seo_url); ?>" />
    <meta name="site_name" content="<?php echo esc_attr($ucmm_seo_sitename); ?>" />
    <meta name="author" content="<?php echo esc_attr($ucmm_seo_admin); ?>">
    <meta name="keywords" content="<?php echo esc_attr($ucmm_seo_keywords); ?>">
    <title><?php echo esc_html(get_bloginfo('name')); ?></title>

    <link href="<?php echo plugins_url('assets/css/fa-brands.min.css', __FILE__); ?>" rel="stylesheet">
    <link href="<?php echo plugins_url('assets/css/fontawesome.min.css', __FILE__); ?>" rel="stylesheet">

    <!-- Google Analytics -->
    <?php if (!empty($ucmm_ga_tracking_code)) : ?>
        <?php echo $ucmm_ga_tracking_code; ?>
    <?php endif; ?>

    <style media="screen">
        html, body {
            height: 100%;
            margin: 0;
            width: 100%;
            display: table;
            text-align: center;
            background-image: url(<?php echo esc_url($ucmm_bg ?: plugins_url('img/coming-soon.png', __FILE__)); ?>);
            background-size: cover;
            background-position: center;
        }
        @media only screen and (max-width: 600px) {
            body {
                background-image: url(<?php echo esc_url($ucmm_mobile_bg_image ?: plugins_url('img/mobile-background.png', __FILE__)); ?>);
            }
        }
        .youtube-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        .youtube-background iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }
        h1 {
            font-size: 60px;
            color: <?php echo esc_attr($ucmm_header_text_color); ?>;
            text-transform: uppercase;
        }
        .ucmm-logo {
            padding-top: <?php echo empty($ucmm_logo) ? '70px' : '20px'; ?>;
            text-align: center;
        }
        .ucmm-logo img {
            width: <?php echo esc_attr($ucmm_logo_width ?: '100px'); ?>;
            height: <?php echo esc_attr($ucmm_logo_height ?: '100px'); ?>;
        }
        h2 {
            font-size: 20px;
            color: <?php echo esc_attr($ucmm_footer_text_color); ?>;
            margin: 0;
        }
        .footer-love {
            bottom: 0;
            padding: 10px;
            text-align: center;
            color: <?php echo esc_attr($ucmm_love_text_color); ?>;
            position: <?php echo esc_attr($ucmm_love_position); ?>;
        }
        .social-links a {
            margin: 0 10px;
            color: inherit;
            font-size: 20px;
        }
        <?php if (!empty($ucmm_custom_css)) : ?>
            <?php echo $ucmm_custom_css; ?>
        <?php endif; ?>
        
        .login-sidebar {
            position: fixed;
            right: 
            position: fixed;
            right: 20px;
            top: 20px;
            background-color: <?php echo esc_attr($ucmm_login_bg_color); ?>;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }
        .login-sidebar input[type="text"],
        .login-sidebar input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            color: <?php echo esc_attr($ucmm_login_text_color); ?>;
        }
        .login-sidebar input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: <?php echo esc_attr($ucmm_login_text_color); ?>;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        .login-sidebar input[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

<?php if (!empty($ucmm_youtube_bg_video)) : ?>
    <div class="youtube-background">
        <iframe src="https://www.youtube.com/embed/<?php echo esc_attr($ucmm_youtube_bg_video); ?>?autoplay=1&loop=1&playlist=<?php echo esc_attr($ucmm_youtube_bg_video); ?>&mute=1&controls=0&showinfo=0&modestbranding=1&iv_load_policy=3&rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
    </div>
<?php endif; ?>

<div class="ucmm-logo">
    <?php if (!empty($ucmm_logo)) : ?>
        <img src="<?php echo esc_url($ucmm_logo); ?>" alt="Logo" width="<?php echo esc_attr($ucmm_logo_width); ?>" height="<?php echo esc_attr($ucmm_logo_height); ?>" />
    <?php else : ?>
        <h1><?php echo esc_html($ucmm_header); ?></h1>
    <?php endif; ?>
</div>

<h2><?php echo esc_html($ucmm_footer); ?></h2>

<!-- Display social media links -->
<div class="social-links">
    <?php foreach ($ucmm_social_links as $key => $link) : ?>
        <?php if (!empty($link)) : ?>
            <a href="<?php echo esc_url($link); ?>" target="_blank"><i class="fab fa-<?php echo esc_attr(str_replace('ucmm_', '', $key)); ?>"></i></a>
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<!-- Footer love text -->
<?php if ($ucmm_footer_love) : ?>
    <div class="footer-love">
        <?php echo esc_html__('Powered by UCMM Plugin', 'ucmm-text-domain'); ?>
    </div>
<?php endif; ?>

<!-- Login sidebar -->
<?php if ($ucmm_enable_login) : ?>
    <div class="login-sidebar">
        <form action="<?php echo esc_url(wp_login_url()); ?>" method="post">
            <input type="text" name="log" placeholder="Username" required />
            <input type="password" name="pwd" placeholder="Password" required />
            <input type="submit" value="Login" />
        </form>
    </div>
<?php endif; ?>

</body>
</html>
