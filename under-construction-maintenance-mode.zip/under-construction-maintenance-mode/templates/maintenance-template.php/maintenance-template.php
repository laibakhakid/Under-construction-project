<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title(); ?></title>
    <?php wp_head(); ?>
    <style>
        body {
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
        }
        .maintenance-message {
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            max-width: 600px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="maintenance-message">
        <h1><?php echo esc_html( get_option( 'maintenance_message', 'Site is under maintenance' ) ); ?></h1>
        <p><?php _e( 'We are currently performing maintenance on our site. Please check back later.', 'ucmm-wpbrigade' ); ?></p>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
